package com.tarasantoniuk.payment.enums;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED
}