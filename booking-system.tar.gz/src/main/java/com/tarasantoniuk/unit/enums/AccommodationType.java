package com.tarasantoniuk.unit.enums;

public enum AccommodationType {
    HOME,
    FLAT,
    APARTMENTS
}