package com.tarasantoniuk.booking.enums;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}